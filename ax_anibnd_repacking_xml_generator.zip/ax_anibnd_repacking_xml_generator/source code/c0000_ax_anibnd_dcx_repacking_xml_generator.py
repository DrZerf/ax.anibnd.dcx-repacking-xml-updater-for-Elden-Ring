import os
import shutil


def generate_xml_entries(output_file):
    current_dir = input("Enter the path of the folder containing .hkx files \n (E.g.: C:\\Users\\XXX\\Desktop\\Elden_ring_modengine\\mod\\chr\\c0000_a0x-anibnd-dcx\\GR\data\\INTERROOT_win64\\chr\\c0000\\hkx\\a0x_compendium)\n")  
    dcx_folder = None
    folder_path = current_dir  
    compendium_path = folder_path.split("-dcx")[1] if "-dcx" in folder_path else ""
    if not compendium_path.endswith("\\"):
        compendium_path += "\\"

    while current_dir:
        if current_dir.endswith("-dcx"):
            dcx_folder = current_dir
            break
        current_dir, tail = os.path.split(current_dir)
    if not dcx_folder:
        print("Error: Make sure the xml_creator is located in the c*x_compendium folder")
        return

    input_xml_path = os.path.join(dcx_folder, "_yabber-bnd4.xml")
    backup_xml_path = os.path.join(dcx_folder, "_yabber-bnd4_backup.xml")

    if os.path.exists(input_xml_path):
        shutil.copy(input_xml_path, backup_xml_path)
        print("Backup of _yabber-bnd4.xml created successfully:")


    with open(input_xml_path, 'r') as input_file:
        first_29_lines = input_file.readlines()[:29]


    with open(output_file, 'w') as f:
        for line in first_29_lines:
            f.write(line)
        f.write("</file>\n")
        for filename in os.listdir(folder_path):
            if filename.endswith('.hkx'):
                file_id = filename.replace('a', '1').split('_')[0][1:] + filename.split('_')[1].split('.')[0]
                f.write(" " * 4 + "<file>\n")
                f.write(" " * 6 + "<flags>0x40</flags>\n")
                f.write(" " * 6 + "<id>1{}</id>\n".format(file_id))
                f.write(" " * 6 + "<root>N:\\</root>\n")
                f.write(" " * 6 + "<path>{}</path>\n".format(compendium_path + "\\" + filename))
                f.write(" " * 4 + "</file>\n")
        f.write("  </files>\n")
        f.write("</bnd4>\n")
    # Overwrite _yabber-bnd4.xml with the content of output.xml
    os.replace(output_file, input_xml_path)


    print(r"_yabber-bnd4.xml file generated successfully! Have a nice day :)")
    print("\n")

generate_xml_entries('_yabber-bnd4.xml')

print("Press Enter to exit...")
input() 
print("Exiting program...")

